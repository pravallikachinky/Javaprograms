package com.cg.lab2;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Author {
	@Id
	private String AuthorId;
	@Override
	public String toString() {
		return "Author [AuthorId=" + AuthorId + ", FirstName=" + FirstName
				+ ", middleName=" + middleName + ", LastName=" + LastName
				+ ", PhoneNo=" + PhoneNo + "]";
	}
	public String getAuthorId() {
		return AuthorId;
	}
	public void setAuthorId(String authorId) {
		AuthorId = authorId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	private String FirstName;
	private String middleName;
	private String LastName;
	private String PhoneNo;

}
