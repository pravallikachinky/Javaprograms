package com.cg.lab2;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class MainAuthor {

	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
	//	Author au=new Author();
		
		//INSERT THE VALUES INTO TABLE(CREATION)
		/*au.setAuthorId("1002");
		au.setFirstName("prathyusha");
		au.setMiddleName("pinky");
		au.setLastName("Gilla");
		au.setPhoneNo("8978128918");
		au.setAuthorId("1003");
		au.setFirstName("adarsh");
		au.setMiddleName("sunny");
		au.setLastName("Gilla");
		au.setPhoneNo("7898129078");
		au.setAuthorId("1004");
		au.setFirstName("Samrudh");
		au.setMiddleName("apple");
		au.setLastName("Gilla");
		au.setPhoneNo("89987146290");*/
		
		/*//RETRIEVE THE VALUES FROM TABLE
		//Author au1=em.find(Author.class, 1001);
		TypedQuery<Author> query=em.createQuery("select auth from Author auth",Author.class);
        List<Author> author=query.getResultList();
        for(Author auth:author){
        	System.out.println(auth);
        }
*/		

		/*//UPDATE THE VALUES
		Author au2=em.find(Author.class, "1002");
		au2.setPhoneNo("9878195687");*/
		
		//DELETE THE ID
		Author au3=em.find(Author.class, "1001");
		em.remove(au3);
		
		em.getTransaction().begin();
		//em.persist(au2);*/
		em.getTransaction().commit();
		em.close();
		fac.close();

	}

}
