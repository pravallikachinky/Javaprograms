package com.cg.lab3;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class BookTable2 {
 @Id
 @GeneratedValue
 private int isbn;
 private String title;
 private double price;
 
 @ManyToOne
 private AuthorTable2 author;
 public AuthorTable2 getAuthor() {
	return author;
}
public void setAuthor(AuthorTable2 author) {
	this.author = author;
}
public int getIsbn() {
	return isbn;
}
public void setIsbn(int isbn) {
	this.isbn = isbn;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}

}
