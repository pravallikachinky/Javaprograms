package com.cg.lab3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class AuthorTable2 {
	@Id
	@GeneratedValue 
	private int id;
	 private String name;
	 
	 @OneToMany(cascade=CascadeType.ALL)
	 private List<BookTable2> buk=new ArrayList<BookTable2>();
 
public List<BookTable2> getBuk() {
		return buk;
	}
	public void setBuk(List<BookTable2> buk) {
		this.buk = buk;
	}
public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
