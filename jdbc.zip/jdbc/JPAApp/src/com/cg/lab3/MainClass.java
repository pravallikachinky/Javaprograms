package com.cg.lab3;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fac.createEntityManager();
		
		AuthorTable2 auth=new AuthorTable2();
		auth.setName("Charles");
		
		AuthorTable2 auth1=new AuthorTable2();
		auth.setName("Hyun");
		
		BookTable2 book=new BookTable2();
		
		book.setPrice(700.00);
		book.setTitle("Barbie");
		
		BookTable2 book1=new BookTable2();
		
		book1.setPrice(900.00);
		book1.setTitle("Haunted house");
		book.setAuthor(auth);
		book1.setAuthor(auth);
		
		
		
		auth.getBuk().add(book);
		auth.getBuk().add(book1);
		
		TypedQuery<BookTable2> query=em.createQuery("select title from BookTable2 where price is between 500 and"
				+ "1000",BookTable2.class);
		
		em.getTransaction().begin();
		em.persist(auth);
		//em.persist(bt);
		em.getTransaction().commit();
		em.close();
		fac.close();
		

	}

}
