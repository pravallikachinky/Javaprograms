package com.cg;

public class UserDetail1 {

	public static void main(String[] args) {
		

	}

}
