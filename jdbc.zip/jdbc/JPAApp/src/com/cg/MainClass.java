package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
	//	UserDetails u1=new UserDetails();
		/*To display details*/
		UserDetails u=em.find(UserDetails.class, 102);
		System.out.println(u.getUserId()+" "+u.getUserName()+" "+u.getGender()+" "+u.getAge());
		
		/* to delete id*/
		
		UserDetails user=em.find(UserDetails.class, 0);
		em.remove(user);
		//u1.setUserId(1001);
		//u1.setUserName("Kim So");
		//u1.setGender("female");
		//u1.setAge(30);
		em.getTransaction().begin();
	//	em.merge(u1);
		em.getTransaction().commit();
		System.out.println("done");
		em.close();
		factory.close();
	}

}
