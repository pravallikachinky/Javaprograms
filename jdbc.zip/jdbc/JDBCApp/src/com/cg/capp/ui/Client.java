package com.cg.capp.ui;

public class Client {

	public static void main(String[] args) {
		

	}

}
