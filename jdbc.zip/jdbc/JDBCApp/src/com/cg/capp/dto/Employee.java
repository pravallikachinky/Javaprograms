package com.cg.capp.dto;

public class Employee {

}
