package com.cg.capp.exception;

public class JDBCAppException extends Exception{

	public JDBCAppException(){
		super();
	}
	public JDBCAppException(String msg){
		super(msg);
	}
}
