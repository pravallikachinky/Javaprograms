package com.cg.capp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.capp.exception.JDBCAppException;

public class Dbutil {
 public static Connection getConnection() throws JDBCAppException{
	 String url="jdbc:oracle:thin:@localhost:1521:xe";
	 
 try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		return DriverManager.getConnection(url,"system","orcl11g");
	} catch (ClassNotFoundException e) {
		throw new JDBCAppException(e.getMessage());
	} catch (SQLException e) {
		throw new JDBCAppException(e.getMessage());
	}
 }
}
