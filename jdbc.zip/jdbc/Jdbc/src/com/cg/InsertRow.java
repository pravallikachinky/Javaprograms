package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertRow {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter employee id");
			int id=Integer.parseInt(sc.nextLine());
			System.out.println("Enter name");
			String name=sc.nextLine();
			System.out.println("Enter gender");
			String gender=sc.nextLine();
			System.out.println("enter age");
			int age=Integer.parseInt(sc.nextLine());
			System.out.println("Enter salary");
			double salary=Double.parseDouble(sc.nextLine());
			PreparedStatement stat=con.prepareStatement("INSERT INTO employee values(?,?,?,?,?)");
			stat.setInt(1, id);
			stat.setString(2, name);
			stat.setString(3, gender);
			stat.setInt(4, age);
			stat.setDouble(5, salary);
			int res=stat.executeUpdate();
			System.out.println("Row inserted " +res);
			stat.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
