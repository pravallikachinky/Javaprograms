package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SalaryBased {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the lower limit");
			double d1=Double.parseDouble(sc.nextLine());
			System.out.println("Enter the upper limit");
			double d2=Double.parseDouble(sc.nextLine());
			PreparedStatement stat=con.prepareStatement("SELECT name,salary from employee where salary "
					+ "between ? and ? ");
			stat.setDouble(1, d1);
			stat.setDouble(2, d2);
			
			ResultSet rs=stat.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString(1)+ " " + rs.getDouble("salary"));
		}
			stat.close();
			rs.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
