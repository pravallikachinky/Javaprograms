package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class employeeId {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter employee id");
			int id=Integer.parseInt(sc.nextLine());
			CallableStatement stat=con.prepareCall("{call prcGetEmpById(?,?,?)}");
			stat.setInt(1, id);
			stat.registerOutParameter(1, Types.VARCHAR);
			stat.registerOutParameter(3, Types.NUMERIC);
			stat.execute();
			String name=stat.getString(2);
			double salary=stat.getDouble(3);
			
			System.out.println("Name : " +name+ ",Salary "  +salary);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
