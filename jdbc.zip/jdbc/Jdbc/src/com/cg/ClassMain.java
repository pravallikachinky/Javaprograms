package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ClassMain {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Scanner scan=new Scanner(System.in);
			System.out.println("enter the ");
			String g=scan.nextLine();
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			PreparedStatement stat=con.prepareStatement("SELECT * FROM employee WHERE GENDER=?");
			stat.setString(1, g);
			ResultSet rs=stat.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+ " "+rs.getString(2)+ " " +rs.getString("gender")+" " + rs.getInt(4)+" "+rs.getDouble(5));
			}
			stat.close();
			rs.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
