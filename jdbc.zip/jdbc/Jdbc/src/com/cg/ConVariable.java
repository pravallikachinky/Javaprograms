package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;

public class ConVariable {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection(url,"system","orcl11g");
			con.setAutoCommit(false);
			PreparedStatement stat=con.prepareStatement("update employee set salary=salary+100 where"
					+ " eno=1002");
			PreparedStatement stat1=con.prepareStatement("update employee set salary=salary-100 where"
					+ " eno=1004");
			PreparedStatement stat2=con.prepareStatement("delete employee where eno=1003");
			stat.executeUpdate();
			stat1.executeUpdate();
			Savepoint svpt=con.setSavepoint();
			stat2.executeQuery();
			con.rollback(svpt);
			System.out.println("Done!!");
			con.commit();
	}
		 catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
