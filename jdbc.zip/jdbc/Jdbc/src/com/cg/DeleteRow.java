package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteRow {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url,"system","orcl11g");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter employee id");
			int age=Integer.parseInt(sc.nextLine());
			PreparedStatement stat=con.prepareStatement("DELETE employee WHERE age=?");
			stat.setInt(1, age);
			int res=stat.executeUpdate();
			System.out.println("Deleted row " +res);
			stat.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	}


