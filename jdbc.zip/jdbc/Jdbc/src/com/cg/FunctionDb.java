package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class FunctionDb {

	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url,"system","orcl11g");
			con.setAutoCommit(false);
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter employee id");
			int id=Integer.parseInt(sc.nextLine());
			CallableStatement stat=con.prepareCall("{?=call fnGetSalary(?)}");
			stat.setInt(2, id);
			stat.registerOutParameter(1, Types.NUMERIC);
			stat.execute();
			
			double salary=stat.getDouble(1);
			
			System.out.println( "Salary "  +salary);
			con.rollback();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
