package com.cg.plp.exception;

public class AccountException extends Exception {
 public AccountException(){
	 super();
 }
 public AccountException(String msg){
	 super(msg);
 }
}
