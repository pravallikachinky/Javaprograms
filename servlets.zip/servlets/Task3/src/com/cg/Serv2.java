package com.cg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet({ "/Serv2", "/fromServ1" })
public class Serv2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public Serv2() {
        super();
       
    }

		/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("From servlet2");
		String res=(String) request.getAttribute("conStr");
		String low=res.toUpperCase();
		//request.setAttribute("result", low);
		System.out.println("Bye from servlet2");
		System.err.println(low);
	}*/
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String resu=(String) getServletContext().getAttribute("val");
    //	String res=(String) request.getAttribute("strng");
    String low=resu.toUpperCase();
    getServletContext().setAttribute("res", low);
        
    }
    
}

