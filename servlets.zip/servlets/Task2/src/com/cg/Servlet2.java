package com.cg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet({ "/Servlet2", "/fromServlet1" })
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public Servlet2() {
        super();
       
    }

		/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("From servlet2");
		String res=(String) request.getAttribute("conStr");
		String low=res.toUpperCase();
		//request.setAttribute("result", low);
		System.out.println("Bye from servlet2");
		System.err.println(low);
	}*/
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String resu=request.getParameter("strng");
  
    	//	String res=(String) request.getAttribute("strng");
    String low=resu.toUpperCase();
    System.out.println(low);
    response.getWriter().print("<html><boby>"
			+ "<center><h4>From servlet2 the result is<br/> "
			+ "the result is::"+low+"</h4></center>" 
			
			+ "</html></boby>");
    
    }
    
}
