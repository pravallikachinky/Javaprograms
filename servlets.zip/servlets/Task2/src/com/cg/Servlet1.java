package com.cg;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Servlet1() {
        super();
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s1=request.getParameter("str1");
		String s2=request.getParameter("str2");
		String s3=s1+s2;
		System.out.println("From servlet1");
		//request.setAttribute("conStr", s3);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/fromServlet1");
	//	dispatcher.include(request, response);
		
		response.sendRedirect("Servlet2?strng="+s3);
	
	}

}
