package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.service.AddService;
import com.cg.service.AddServiceImpl;

/**
 * Servlet implementation class MyServlet1
 */
@WebServlet("/MyServlet1")
public class MyServlet1 extends HttpServlet {
	AddService service=new AddServiceImpl();
	private static final long serialVersionUID = 1L;
       
       public MyServlet1() {
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int n1=Integer.parseInt(request.getParameter("num1"));
		int n2=Integer.parseInt(request.getParameter("num2"));
		
		int res=service.addNum(n1, n2);
		System.out.println(res);
		response.getWriter().print("<html><boby>"
				+ "<center><h4>Addition of two numbers<br/> "
				+ "the result is::"+res+"</h4></center>" 
				
				+ "</html></boby>");
	}

}
