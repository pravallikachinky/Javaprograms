package com.cg.service;

import com.cg.bean.NumberBean;

public class AddServiceImpl implements AddService {

	NumberBean bean=new NumberBean();
	@Override
	public int addNum(int num1, int num2) {
		bean.setNum1(num1);
		bean.setNum2(num2);
		return (bean.getNum1()+bean.getNum2());
		//return bean.getNum1()+bean.getNum2() ;
	}

	
	

}
