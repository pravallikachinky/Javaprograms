package com.cg.service;

import com.cg.bean.NumberBean;

public interface AddService {
 int addNum(int num1,int num2);
}
