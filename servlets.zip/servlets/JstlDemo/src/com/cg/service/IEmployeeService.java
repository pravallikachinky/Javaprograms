package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.EmployeeBean;

public interface IEmployeeService {
 ArrayList<EmployeeBean> getAllEmp();
}
