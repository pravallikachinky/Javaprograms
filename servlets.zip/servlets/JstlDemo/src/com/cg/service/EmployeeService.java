package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.EmployeeBean;

public class EmployeeService implements IEmployeeService {

	@Override
	public ArrayList<EmployeeBean> getAllEmp() {
		ArrayList<EmployeeBean> list=new ArrayList<EmployeeBean>();
		list.add(new EmployeeBean(101,"e101", 1000.00));
		list.add(new EmployeeBean(102,"e102", 5000.00));
		
		return list;
	}

}
