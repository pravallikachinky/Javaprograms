package com.cg.SpringBoot;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Message;
import com.cg.model.Sender;
import com.cg.service.MessageRepo;

@RestController
public class SpringBootController {
	@Autowired
	private MessageRepo repo;
	
	@RequestMapping(value="/")
	public String sayHello() {
		
		return "TGIF";
	}
	
	@RequestMapping(value="/Message")
	public Message sendMessage() {
		
		Message msg=new Message();
		Sender send=new Sender();
		send.setName("hello");
		msg.setText("From Message");
		msg.setName(send);
		
		return msg;
	}
	
	@RequestMapping(value="/sendMessage",method=RequestMethod.POST)
	public Message receiveMsg(@RequestBody Message m) {
		repo.save(m);
		return m;
	}
	
	@RequestMapping(value="/sendsimple")
	public String receiveSimpleMsg (String str) {
		
		return str;
	}
	
	@RequestMapping(value="/getm")
	public Message getMsg(int id) {
		
		return repo.getOne(id);
	}
	@RequestMapping(value="/getname")
	public Message getName(String name) {
		
	
		return repo.getText(name);
	}
}
