package com.cg.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Day {
	
	@Override
	public String toString() {
		return "Day [name=" + name + ", games=" + games + "]";
	}
	
	
	@Id
	@GeneratedValue
	private int dayId;
	
	private String name;
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Game1> games;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Game1> getGames() {
		return games;
	}
	public void setGames(List<Game1> games) {
		this.games = games;
	}

}
