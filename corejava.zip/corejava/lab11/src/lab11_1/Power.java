package lab11_1;

import java.util.function.BiFunction;

public class Power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiFunction<Integer,Integer,Double> b=(x,y)->Math.pow(x,y);
		double result=b.apply(3, 3);
		System.out.println(result);
	}

}
