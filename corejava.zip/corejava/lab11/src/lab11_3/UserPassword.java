package lab11_3;

import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;

public class UserPassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String user="cap@gmail.com";
		String pass="cap123*";
		boolean res=false;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the username");
			String s=sc.nextLine();
			System.out.println("Enter the password");
			String s1=sc.nextLine();
			if((user.equals(s)) && (pass.equals(s1))){
			BiFunction<String,String,Boolean> str=(x,y)->{
			boolean b=x.matches("[A-Za-z0-9]+@[a-z]+\\.com");
			boolean b1=y.matches("[a-z0-9]+\\*+{2,9}");
			if(b && b1)
				return true;
			else
				return false;
			};
			
			 res=str.apply(s, s1);
			 System.out.println(res);
			}
			 if(res){
				 System.out.println("It matches the custom values ");
			 }else
				 System.out.println("It doesnot match custom values");
		
		
	}

}
