package lab11_2;

import java.util.function.Function;

public class LamdaSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<String,String> f=x->{
			
			String str="";
			int len=x.length();
			char c[]=x.toCharArray();
			for(int i=0;i<len;i++)
			{
				str+=c[i]+" ";
			}
			return str;
		};
		String res=f.apply("Pravallika");
		System.out.println(res);
	}

}
