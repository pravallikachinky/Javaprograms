package lab7_4pkg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class main_square {
	public static HashMap getSquares(int[] arr){
		Map<Integer,Integer> map=new HashMap<Integer, Integer>();
		for (int n : arr) {
			map.put(n,n*n);
			
		}
		return (HashMap) map;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[]= {1,2,3,4,5,6,7,8,9,};
		HashMap<Integer,Integer> sqnum=getSquares(array);
		Iterator<Integer> it=sqnum.keySet().iterator();
		while(it.hasNext()){
			Integer Key=it.next();
			System.out.println(Key+":"+sqnum.get(Key));
		}
		
		
		
	}

}
