package lab7_1pkg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReverseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list1=new ArrayList<Integer>();
		List<Integer> list2=new ArrayList<Integer>();

		/*Scanner sc=new Scanner(System.in);
		System.out.println("enter the values");
*/		list1.add(12);
		list1.add(16);
		list1.add(45);
		list1.add(52);
		list1.add(28);
		// String str=sc.nextLine();
		
		 System.out.println("before reverse the list is");
		
		for (int i = 0; i < list1.size(); i++) {
			
			  int val=list1.get(i);
			  System.out.println(val);
			  String str=val+"";
			  StringBuilder str1=new StringBuilder(str);
			  str1.reverse();
			 String str2=str1.toString();
			//System.out.println(str1);
			 int result=Integer.parseInt(str2);
			 list2.add(result);
		}
		System.out.println("after reversing the list is");
		for (int i = 0; i < list2.size(); i++) {
			System.out.println(list2.get(i));
		}
		
	}

}