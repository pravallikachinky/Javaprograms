package lab73pkg;

import java.util.ArrayList;
import java.util.List;

public class RemoveList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1=new ArrayList<>();
		list1.add("hello");
		list1.add("hi");
		list1.add("how");
		list1.add("are");
		list1.add("you");
					System.out.println(list1);
		

		List<String> list2=new ArrayList<>();
		list2.add("chinky");
		list2.add("pinky");
		list2.add("sunny");
		list2.add("apple");
		list2.add("sony");

		
			System.out.println(list2);
		list1.addAll(list2);
		System.out.println(list1);
		list1.removeAll(list2);
		System.out.println(list1);
		


	}

}
