package lab7_2;

import java.util.ArrayList;

import com.sun.org.apache.xpath.internal.operations.Operation;

public class StringOp {

	public ArrayList operationOb(String str1,String str2){
		
		ArrayList<String> arr=new ArrayList<String>();
		int n=str1.length();
		String ch[]=new String[n];
		String[] str= new String[n];
		String res="";
		
		for(int i=0;i<n;i++){
			if(i%2!=0){
				res=str2;
			}else
				ch[i]=""+str1.charAt(i);
			    res=res+ch[i];
			    str[i]=ch[i];
			    
		}
		System.out.println("print the string" +res);
		arr.add(res);
		
		//Reversing the last occurrence
		int c=0;
		int count=0;
	    c=n-1;
	    String reversed="";
	    for(int i=0;i<n;i++){
	    	if(ch[i].equals(str2))
	    		count++;
	    	if(count>1){
	    		StringOp op=new StringOp();
	    		String rev=op.reverse(str2);
	    		for(int i1=0;i1<n;i1++){
	    			
	    		}
	    	}
	    }
	}
}
