package lab7_2;

import java.util.Scanner;

public class StringCase {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the string1");
		String str1=scan.nextLine();
		
		
		System.out.println("Enter the string2");
		String str2=scan.nextLine();
		
		StringOp o=new StringOp();
		o.OperationOb(str1, str2);
		
		
	}

}
