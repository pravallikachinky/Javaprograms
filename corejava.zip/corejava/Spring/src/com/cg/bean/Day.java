package com.cg.bean;

import java.util.List;

public class Day {
 private String dName;
 private List<Game> games;
public String getdName() {
	return dName;
}
public void setdName(String dName) {
	this.dName = dName;
}
public List<Game> getGames() {
	return games;
}
public void setGames(List<Game> games) {
	this.games = games;
}
}
