package com.cg.dao;

import com.cg.bean.Day;

public interface SportDao {
	 public Day save(Day d);
}
