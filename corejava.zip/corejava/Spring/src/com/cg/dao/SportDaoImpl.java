package com.cg.dao;

import com.cg.bean.Day;

public class SportDaoImpl implements SportDao {

	@Override
	public Day save(Day d) {
		
		return null;
	}

}
