package com.cg.eis.service;

public interface Service {
 public String insurance(long salary, String designation);
 
}
