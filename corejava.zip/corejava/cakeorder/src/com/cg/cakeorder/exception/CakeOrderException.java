package com.cg.cakeorder.exception;

public class CakeOrderException extends Exception {
  public CakeOrderException(){
	  super();
  }
  public CakeOrderException(String message){
	  super(message);
  }
}
