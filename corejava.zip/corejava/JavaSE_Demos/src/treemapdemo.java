import java.util.TreeMap;


public class treemapdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,String> employees=new TreeMap<Integer,String>();
		employees.put(1001, new employee(1001,"sunil","male",23000));

		employees.put(1001, new employee(1002,"mark","male",44000));

		employees.put(1001, new employee(1003,"sara","female",45000));

		employees.put(1001, new employee(1001,"sunil","male",23000));
	}

}
