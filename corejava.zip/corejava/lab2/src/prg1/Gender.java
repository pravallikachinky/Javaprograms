package prg1;

public enum Gender {
	F,M;
}
