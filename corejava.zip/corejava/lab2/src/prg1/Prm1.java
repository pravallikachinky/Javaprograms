/**
 * 
 */
package prg1;

/**
 * @author pgilla
 *
 */
public class Prm1 {

	/**
	 * @param args
	 */
	public static void main(String[] chin) {
		// TODO Auto-generated method stub
		System.out.println("Personal Details:");
		System.out.println("---------------------");
		System.out.println("First Name : "+chin[0]);
		System.out.println("Last Name : "+chin[1]);
		System.out.println("Gender : "+chin[2]);
		System.out.println("Age : "+chin[3]);
		System.out.println("Weight : "+chin[4]);
   
	}

}
