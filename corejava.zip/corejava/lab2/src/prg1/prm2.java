/**
 * 
 */
package prg1;

/**
 * @author pgilla
 *
 */
public class prm2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
				int age=Integer.parseInt(args[0]);
					if(age>=0)
						System.out.println(+age +" is a positive number");
					else
						System.out.println(+age + " is a negative number");
		    	  
			}

		

	

}
