package lab3prg;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Prm3_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     ZonedDateTime zob= ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
     System.out.println(zob);
	}

}
