package lab3prg;

public class Check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   StringBuffer sb=new StringBuffer("hello");
   sb.delete(0, 1);
   System.out.println(sb);
	}

}
