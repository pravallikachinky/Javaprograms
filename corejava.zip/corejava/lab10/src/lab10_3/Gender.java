package lab10_3;

public enum Gender {
	F,M;
}
