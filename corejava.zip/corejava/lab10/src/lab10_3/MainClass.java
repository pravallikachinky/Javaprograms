package lab10_3;





public class MainClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Gender1 g1=new Gender1("chinky","gilla",Gender.F);
	      g1.printdetails();	
	      }
}
