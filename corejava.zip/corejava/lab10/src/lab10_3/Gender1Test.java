package lab10_3;

import static org.junit.Assert.*;

import org.junit.Test;

public class Gender1Test {
 Gender1 gend=new Gender1();
	@Test
	public void testGetFirstname() {
		gend.setFirstname("Pravallika");
		assertEquals("Pravallika", gend.getFirstname());
	}

	@Test
	public void testSetFirstname() {

		gend.setFirstname("Pravallika");
		assertNotEquals("pravallika", gend.getFirstname());
	}

	@Test
	public void testGetLastname() {
		gend.setLastname("Gilla");
		assertEquals("Gilla", gend.getLastname());
	}

	@Test
	public void testSetLastname() {
		gend.setLastname("Gilla");
		assertNotEquals("gilla", gend.getLastname());
	}

	/*@Test
	public void testGetGen() {
		gend.setGen.F;
     
	}

	@Test
	public void testSetGen() {
		fail("Not yet implemented");
	}*/

	/*@Test
	public void testPrintdetails() {
	firstname=Pravallika;
	
	}*/

}
