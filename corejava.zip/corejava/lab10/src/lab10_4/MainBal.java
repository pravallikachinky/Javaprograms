package lab10_4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MainBal {

	public static void main(String[] args) throws EmployeeServiceException {
		// TODO Auto-generated method stub
		Person p=new Person("smith",23);
		
		
		Account acc=new AccountSub();
		acc.setAccholder(p);
		acc.setBalance(2000);
		System.out.println(acc);
		acc.deposit(2000);
		
		
	
		
		Person p1=new Person("kathy",23);
		Account acc1=new AccountSub();
		acc1.setAccholder(p1);

		acc.setBalance(3000);
		System.out.println(acc1);
		acc.withdraw(2000);
		try{
			if(acc.getbalance()<=3000 || acc1.getbalance()<=3000)
			{
				throw new EmployeeServiceException();
			}
		}catch(EmployeeServiceException ee)
		{
			System.out.println(ee);
		}
		
	}

}
