package lab10_4;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeServiceExceptionTest {
  Account acc=new AccountSub();
	@Test
	public void testToString() {
	 acc.setBalance(3000);
	 assertEquals("balance is lessthan 3000 please deposit money",ee.getMessage());
	}

}
