package lab10_4;


public class AccountSub extends Account {
	public void withdraw(double wit)
	{
		setBalance(getBalance()-wit);
		System.out.println("after deposit balance" +getBalance());
	}


}
