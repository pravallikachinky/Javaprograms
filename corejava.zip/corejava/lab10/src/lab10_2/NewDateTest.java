package lab10_2;

import static org.junit.Assert.*;

import org.junit.Test;

public class NewDateTest {

	@Test
	public void testToString() {
		Date d = new Date(10, 5, 1997);
		assertEquals("Date is 10/5/1997", d.toString());
	}

}
