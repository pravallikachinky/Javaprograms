package lab10_2;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest {
	Date d=new Date();
	@Test
	public void testSetDay() {
		d.setDay(5);
		assertEquals(5, d.getDay());
	}

	@Test
	public void testGetDay() {
		d.setDay(5);
		assertNotEquals(6,d.getDay());
	}

	@Test
	public void testSetMonth() {
		d.setMonth(11);
		assertEquals(11,d.getMonth());
	}

	@Test
	public void testGetMonth() {
		d.setMonth(12);
		assertNotEquals(11,d.getMonth());
	}

	@Test
	public void testSetYear() {
		d.setYear(1996);
		assertEquals(1996,d.getYear());
	}

	@Test
	public void testGetYear() {
		d.setYear(1997);
		assertNotEquals(1996,d.getYear());
	}

}
