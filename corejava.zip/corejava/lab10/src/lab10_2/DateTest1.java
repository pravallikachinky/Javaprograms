package lab10_2;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest1 {
	Date dt=null;
	
	@Test
	public void testDate(int i, int j, int k) {
		dt = new Date(10, 5, 1997);
		assertEquals("Date is 10/5/1997", dt.toString());
	}

	
}
