package lab6pkg;

import java.util.Scanner;


public class Main61 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Prm61 pp=new Prm61();
		pp.getFirstName();
		pp.getLastName();
		System.out.println("enter the firstname");
		Scanner sf=new Scanner(System.in);
		String s1=sf.nextLine();
	//	char ch[]=s1.toCharArray();
		System.out.println("enter the lasstname");
		String s2=sf.nextLine();
		
			
		
			try{
				if(s1.equals("")||s2.equals(""))
				{
					throw new NameException();

			}
				else
					System.out.println("FIRSTNAME: " +s1);
					System.out.println("FIRSTNAME: " +s2);
			}
				catch(NameException e){
				System.out.println(e);
			}
			
			
			
	}

}
 