package lab6_2pkg;

import java.util.Scanner;

public class MainAgeExp {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the age");
		Scanner a1=new Scanner(System.in);
		Integer age1=a1.nextInt();
		try{
			if(age1<=15){
				throw new AgeException();
			}
		
			else
				System.out.println("the age is " +age1);
		}catch(AgeException ae)
		{
			System.out.println(ae);
		}
		
		
	}

}
