package com.cg.employee.db;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import com.cg.employee.bean.Employee;

public class EmployeeDB {
	private static HashMap<Integer,Employee> empDb=new 
			    HashMap<Integer,Employee>();

	public static HashMap<Integer, Employee> getEmpDb() {
		return empDb;
	}
	static{
		empDb.put(1001,new Employee(1001,"Park Seo","Male",29,"9985851234","Programmer",
				LocalDate.of(2016, Month.APRIL, 21),56000));
		empDb.put(1002,new Employee(1002,"Kim Mi So","Female",28,"8967451390","Team Lead",
				LocalDate.of(2012, Month.AUGUST, 10),78000));
		empDb.put(1003,new Employee(1003,"Young Soon","Male",25,"8978615689","Manager",
				LocalDate.of(1999, Month.FEBRUARY, 12),98000));
	}
}
