package com.cg.employee.service;

import java.util.Collection;
import java.util.List;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.IEmployeeDao;
import com.cg.employee.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {
	IEmployeeDao employeeDao=new EmployeeDao();
	
	public Collection<Employee> getAllEmployees() throws EmployeeException{

		return employeeDao.getAllEmployees();
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		
		return employeeDao.getEmployeeById(id);
	}

	@Override
	public boolean validateEmployee(Employee emp) throws EmployeeException {
		if(validateName(emp.getName())&& validateMobile(emp.getMobile())
				&& validateAge(emp.getAge())){
			return true;
		}
		return false;
	}
	private boolean validateName(String name) throws EmployeeException{
		if(name.isEmpty()||name==null){
			throw new EmployeeException("Employee Name cannot be empty");
		}
		else{
			if(!name.matches("[A-Z][A-Za-z]{3,}")){
				throw new EmployeeException("Name should start with capital letter and it should be having only characters");
			}
			
		}
		return true;
	}
	private boolean validateMobile(String mobile) throws EmployeeException{
		if(!mobile.matches("\\d{10}")){
			throw new EmployeeException("Mobile number should contain 10 digits");
		}
		return true;
	}
	private boolean validateAge(int age) throws EmployeeException{
		if(age>=18 && age<=60)
			return true;
		else{
			throw new EmployeeException("Age should be between 18 and 60");
		}
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.addEmployee(emp);
	}

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(id);
	}

	@Override
	public List<Employee> getEmployeeByDesignation(String designation)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeByDesignation(designation);
	}

	@Override
	public Employee findSeniorMostEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.findSeniorMostEmployee();
	}

	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(emp);
	}
}
