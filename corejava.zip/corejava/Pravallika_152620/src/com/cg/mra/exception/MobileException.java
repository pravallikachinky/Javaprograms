package com.cg.mra.exception;

public class MobileException extends Exception {
	public MobileException(){
		super();
	}
	public MobileException(String message){
		super(message);
	}
}
