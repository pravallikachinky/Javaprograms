package com.cg.mra.db;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public class MobileDB {
	private static HashMap<String, Account> mobDb=new HashMap<String,Account>();
	
	public static HashMap<String, Account> getmobDb(){
		return mobDb;
	}
	static{
		mobDb.put("8978123689",new Account("8978123689","Airtel","Pinky",500.00));
		mobDb.put("9866099893",new Account("9866099893","Idea","Chinky",100.00));
		mobDb.put("9848683067",new Account("9848683067","BSNL","Sunny",1000.00));
		
	}
}
