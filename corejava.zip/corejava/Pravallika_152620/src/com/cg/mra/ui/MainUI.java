package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	Scanner sc=new Scanner(System.in);
	AccountService service=new AccountServiceImpl();
	public static void main(String[] args) {
		String option="";
		MainUI main=new MainUI();
		while(true){
			System.out.println("1.Account Balance Enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			option=main.sc.nextLine();
			switch (option) {
			case "1":
					main.accountBal();
				break;
			case "2":
				 	main.returnAccount();
				break;
			case "3":
					System.exit(0);
				break;
			default:
					System.out.println("Please enter the option between 1 to 3");
				break;
			}
		}

	}
	private void accountBal(){
		System.out.println("Enter the mobile number");
		String mobile=sc.nextLine();
		try {
			Account acc1=service.getAccountDetails(mobile);
			System.out.println("Your Current Balance:" +acc1.getAccountBalance());
		} catch (MobileException e) {
			System.out.println();
			System.err.println("ERROR : " +e.getMessage());
			System.out.println();
		}
	}
	private void returnAccount(){
		System.out.println("Enter the mobile number");
		String mobile=sc.nextLine();
		try {
			boolean result=service.validateMobile(mobile);
			if(result){
				Account acc2=service.getAccountDetails(mobile);
				System.out.println("Enter the recharge amount");
				double recharge=Double.parseDouble(sc.nextLine());
				double amount1=service.rechargeAccount(mobile,recharge);
				acc2.setAccountBalance(amount1);
				System.out.println("Your account recharged successfully Hello " +acc2.getCustomerName()+ " Available Balance is " +acc2.getAccountBalance() );
			}
		} catch (MobileException e) {
			System.out.println();
			System.err.println("ERROR:" +e.getMessage());
			System.out.println();
		}
				
		
		
	}

}
