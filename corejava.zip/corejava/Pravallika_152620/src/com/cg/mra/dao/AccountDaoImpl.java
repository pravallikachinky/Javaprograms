package com.cg.mra.dao;

import java.util.HashMap;
import com.cg.mra.beans.Account;
import com.cg.mra.db.MobileDB;
import com.cg.mra.exception.MobileException;
/**
 * Class Name: AccountDaoImpl
 * Interface implemented: AccountDao
 * Number of methods:2 
 * Name of Methods: getAccountDetails , rechargeAccount
 * Purpose: Getting data and mobile recharge operation
 */

public class AccountDaoImpl implements AccountDao {
	static HashMap<String, Account> mobDb=
			MobileDB.getmobDb();

	@Override
	public Account getAccountDetails(String mobileNo) throws MobileException {
		Account acc=mobDb.get(mobileNo);
		if((acc==null)){
			throw new MobileException("Given Account Id doesnot exist");
		}
		return acc;
		
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount)
			throws MobileException {
		Account acc=mobDb.get(mobileNo);
		if((acc==null)){
			throw new MobileException("Cannot Recharge Account as Given MobileNo does Not Exists");
		}
		Account account=mobDb.get(mobileNo);
		double amount=0;
		amount=rechargeAmount+account.getAccountBalance();
		return (int) amount;
	}

}
