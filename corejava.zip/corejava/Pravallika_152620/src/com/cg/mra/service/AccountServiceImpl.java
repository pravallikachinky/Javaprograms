package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService {
	AccountDao dao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) throws MobileException {
	
			
		return dao.getAccountDetails(mobileNo);
	
	}

	
	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount)
			throws MobileException {
		
		return dao.rechargeAccount(mobileNo,rechargeAmount);
	}


	@Override
	public boolean validateMobile(String mobileNo) throws MobileException {
		if((!mobileNo.matches("\\d{10}")) ){
			throw new MobileException("Please enter the mobileNo with 10 digits ");
		}
		return true;
	}
	}