package com.cg.mra.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

public class AccountServiceTest {
	AccountDao dao;
	@Before
	public void init() {
		dao=new AccountDaoImpl();
	}
	@Test
	public void testRechargeAccount() throws MobileException {
		String mob="9866099893";
		double recharge=200;
		assertNull(dao.rechargeAccount(mob, recharge));
		
	}

}
