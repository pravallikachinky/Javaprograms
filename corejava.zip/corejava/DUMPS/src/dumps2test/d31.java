package dumps2test;

public class d31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder ();
		String h1="helloworld";
		sb.append("hello").append("world");
		if(h1==sb.toString())
			System.out.println("equal");
		else if(h1.equals(sb.toString())){
			System.out.println("they match");
		}
			
	}

}
