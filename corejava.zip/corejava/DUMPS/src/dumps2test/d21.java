package dumps2test;

public class d21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array={1,2,3,4,5};
		int[] array1=new int[5];
		System.arraycopy(array,1,array1,1,4);
		for (int i = 0; i < array1.length; i++) {
			System.out.println(array1[i]);
		}
	}

}
