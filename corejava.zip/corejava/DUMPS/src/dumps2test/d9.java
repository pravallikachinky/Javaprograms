package dumps2test;

public class d9 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		dosomething();
	}
	private static void dosomething() throws Exception{
		System.out.println("before clause");
		if(Math.random()>0.5){
			throw new Exception();
		}
		System.out.println("after the clause");
	}

}
