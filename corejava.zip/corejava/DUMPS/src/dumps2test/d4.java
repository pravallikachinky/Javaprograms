package dumps2test;

public class d4 {
		public static void main(String[] args) {

	/*String msg1=new String("hello");
	String msg2=new String("hello");
	
	if(msg1==msg2)
	{
		System.out.println("equal");
	}
	else if(msg1.equals(msg1))
	{
		System.out.println("not equal");
	}
	
*/
		System.out.println(3+5);	
		System.out.println("RESULT:"+3+5);	
		System.out.println(3+5+ "result");
		System.out.println((3+5)+ "result");	
		System.out.println( "result:" +(3+5));


		}
		
}