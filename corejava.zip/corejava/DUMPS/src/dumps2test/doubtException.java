package dumps2test;

public class doubtException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=5;
		try{
			
				 c=c/0;
			
		}catch(ArithmeticException n)
		{
			System.out.println("sorry!!!!");
		}

	}

}
