/**
 * 
 */
package login;

/**
 * @author pgilla
 *
 */

public class Calc {

	/**
	 * @param args
	 */
	public void print(){
		int c,d ;
		for(int i=0;i<10;i++)
		{
			c=20;
			d=c+i;
			System.out.println(d);
			
		}
	}
	public int addition(int a,int b){
		int c=a+b;
		return c;
	}
	

}
