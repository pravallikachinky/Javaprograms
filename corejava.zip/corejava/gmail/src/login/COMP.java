package login;

public class COMP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a1="A";
		String b="a";
		System.out.println(b.compareTo(a1));

	}

}
