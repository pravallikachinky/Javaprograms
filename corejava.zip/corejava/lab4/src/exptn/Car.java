package exptn;

public class Car {
 
	void readDataFromSensor()
	{
		/*System.out.println("file is open");
		try{
			System.out.println("Data is read");
			int arr[]={};
			System.out.println(arr[0]);
		}finally{
			System.out.println("file is closed");
		}
	}*/
}
}
