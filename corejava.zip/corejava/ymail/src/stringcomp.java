import java.util.List;


public class stringcomp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1=new List<String>();
		list1.add("hyd");
		list1.add("ban");
		list1.add("coc");
		list1.add("ker");
		list1.add("mum");
		
	}

}
