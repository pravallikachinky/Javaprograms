/**
 * 
 */
package login;

/**
 * @author pgilla
 *
 */
public class OPERATOR {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20,day=1;
		switch (day){
		case 1 : 
			System.out.println("sunday");
			break;
		
		}
		float v=21.34f;
		System.out.println(a++);
		a++;
		System.out.println(a);
     boolean status=a>b;
     System.out.println(status);


	}

}
