package login;

public class intedump {
	public static void dosum(Integer x, Integer y){
		System.out.println("integer " +(x+y));
	}
		public static void dosum(int x, int y){
			System.out.println("int " +(x+y));
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dosum(10,20);
	}

}
