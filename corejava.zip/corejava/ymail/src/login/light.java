/**
 * 
 */
package login;

/**
 * @author pgilla
 *
 */
public class light {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
