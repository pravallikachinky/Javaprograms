package com.cg;

public class ClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
