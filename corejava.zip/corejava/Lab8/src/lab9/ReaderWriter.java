package lab9;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderWriter {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file=new File("d:/chinky.txt");
		FileReader fr=new FileReader(file);
		FileWriter fw=new FileWriter("d:/write.txt");
		System.out.println("Original file is:");
		char[] arr=new char[(int)file.length()];
		
		fr.read(arr);
		System.out.println(arr);
		//System.out.println(arr[44]);
		int n=(int) file.length();
		char[] arr2=new char[n];
		
		//fw.write(arr2);
		
		for(int i=0;i<n;i++)
		{
			arr2[i]=arr[n-i-1];
		}
		fw.write(arr2);
		
		System.out.println("Reversed file is:");
		System.out.println(arr2);
		fr.close();
		fw.close();
		
		

	}

}
