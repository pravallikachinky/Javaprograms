package lab8_2;

public class Timer implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Timer t1=new Timer();
		Thread th=new Thread(t1);
		System.out.println("Timer starts");
		th.start();
		
	}

	@Override
	public void run() {
		int count=0;
		
		while(count<=10)
		{
			count++;
			System.out.println(count);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(count==10){
				count=0;
			System.out.println("Timer is refreshing");
			}
		}
		
	}

}
