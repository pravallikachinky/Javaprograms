package lab9_2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EvenNum {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		FileInputStream fi=new FileInputStream("d:/num.txt");
		Scanner scan=new Scanner(fi);
		
		scan.useDelimiter(",");
		while(scan.hasNext())
		{
			String data=scan.next();
			String dataArray[]=data.split(" ");
			char[] ch=data.toCharArray();
			for(int i=0;i<dataArray.length;i=i+2)
				if(ch[i]%2==0)
					System.out.println(ch[i]);
		}
	}

}
