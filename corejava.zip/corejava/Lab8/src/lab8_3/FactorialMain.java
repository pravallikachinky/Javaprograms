package lab8_3;

public class FactorialMain implements Runnable{
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetNumber gnum=new GetNumber();
		
		//GetFactorial fact1=new GetFactorial();
		//fact1.fact(num1);
		Thread t1=new Thread(gnum);

		
		
		
		t1.start();
	
		
		
	}
		@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}

	

