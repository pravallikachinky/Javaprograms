package lab8_3;

public class GetFactorial implements Runnable {
	public GetFactorial(int num1) {
	// TODO Auto-generated constructor stub



		int i,fact1=1;
		for(i=1;i<=num1;i++)
		{
			fact1=fact1*i;
			
			
		}
		System.out.println("Factorial of " +num1+ " is " +fact1);
	}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			
		}
	

}
