package lab8_3;

public class GetNumber implements Runnable{
	public void getnum()
	{
		/*int num;
		num=(int) ((int)10*Math.random());
		System.out.println("Random number is " +num);
		GetFactorial fact1=new GetFactorial(num);
		Thread t2=new Thread(fact1);
		t2.start();*/
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int num;
		num= (int) (10*Math.random());
		System.out.println("Random number is " +num);
		GetFactorial fact1=new GetFactorial(num);
		Thread t2=new Thread(fact1);
		t2.start();
	}
}
