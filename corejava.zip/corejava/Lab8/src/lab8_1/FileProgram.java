package lab8_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileProgram  {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
			
			FileInputStream fis=new FileInputStream("d:/source.txt");
			FileOutputStream fos=new FileOutputStream("d:/target.txt");
			CopyDataThread cdp1=new CopyDataThread();
			cdp1.copy(fis,fos);
			
	}
	
}
