package lab8_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread {
	
	 public void copy(FileInputStream fis , FileOutputStream fos) throws IOException{
		 
		int c;
		
		int len=fis.available();
		System.out.println(len);
		int count=1;
		System.out.println("File copying is started");
		//String s="10 characters are printed";
		while((c=fis.read())!=-1){
			System.out.println((char)c);
			if(((count%10)==0) && (count<=len)){
				fos.write(c);
				System.out.println("---10 characters are copied--- ");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			fos.write(c);
			count++;
		}
		
		System.out.println("File copied successfully");
		fis.close();
		fos.close();
	}

	/*@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}*/

	
}
