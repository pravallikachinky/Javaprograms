package lab8_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class MainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		/*FileInputStream in=new FileInputStream("data.properties");
		Properties props=new Properties();
		props.load(in);
		System.out.println(props.getProperty("name"));
		System.out.println(props.getProperty("company"));
		System.out.println(props.getProperty("city"));
		System.out.println(props.getProperty("state"));
			*/
		Properties p=new Properties();
		p.setProperty("1000","MANU" );
		p.setProperty("1001","ANU" );
		p.setProperty("1002","KIRAN" );
		FileOutputStream out=new FileOutputStream("name.properties");
		p.store(out, "Details ");
		out.close();
		System.out.println("done!!");

		
	}

}
