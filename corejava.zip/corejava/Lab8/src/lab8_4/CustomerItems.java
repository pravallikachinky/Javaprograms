package lab8_4;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class CustomerItems implements Runnable{
	
	
	@Override
	public void run() {
		//Map<Integer,String> items=new HashMap<Integer,String>();
		//items.put(40,"rice");
		//items.put(23,"milk");
		//items.put(10,"eggs");
		System.out.println("Customer giving products to billing person ");
		//System.out.println("Customer purchased products are");
		//for (Object obj:items.keySet()) {
	//		System.out.println( items.get(obj)+ " : " +obj);
			
	//}
		//Set<Integer> arr=items.keySet();
		BillingItems bill=new BillingItems();
		Thread t2=new Thread(bill);
		t2.start();
	}
}
