package lab8_4;

public class ElectronicShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerItems cust=new CustomerItems();
		Thread t1=new Thread(cust);
		t1.start();
	}

}
