package lab8_4;

import java.util.Set;

public class BillingItems implements Runnable {

	/*public BillingItems(Set<Integer> arr) {
		// TODO Auto-generated constructor stub
		int amount=0;
		for (Integer integer1 : arr) {
			amount=amount+integer1;
		}
		System.out.println("Billing person bills the products");
		System.out.println("After billing the amount is");
	//	System.out.println("Total Amount: " +amount);
	}
*/
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Billing person bills the products");
	}

}
