package lab9_3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MainBal {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Person p=new Person("smith",23);
		File file=new File("d:/employee/employee.txt");
		FileWriter fw=new FileWriter(file);
		Account acc=new AccountSub();
		acc.setAccholder(p);
		acc.setBalance(2000);
		System.out.println(acc);
		acc.deposit(2000);
		String str="Account Holder: " +acc.getAccholder()+ " Account Number: "
				+acc.getAccnum()+ " Account Balance: " +acc.getbalance();
		
		
		fw.write(str);
		
		Person p1=new Person("kathy",23);
		Account acc1=new AccountSub();
		acc1.setAccholder(p1);
		
		acc.setBalance(3000);
		System.out.println(acc1);
		acc.withdraw(2000);
		String str1="  Account Holder: " +acc1.getAccholder()+ " Account Number: "
				+acc1.getAccnum()+ " Account Balance: " +acc1.getbalance();
		fw.write(str1);
		try{
			if(acc.getbalance()<=3000 || acc1.getbalance()<=3000)
			{
				throw new EmployeeServiceException();
			}
		}catch(EmployeeServiceException ee)
		{
			System.out.println(ee);
		}
		fw.close();
	}

}
